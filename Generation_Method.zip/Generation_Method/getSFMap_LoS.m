function [sfMap_LoS] = getSFMap_LoS(sigma_LoS,d_sc_sf,d_co_sF,x_Rx_u,x_Rx_l,y_Rx_u,y_Rx_l)
% A function of generating LoS SF term map

Nsf_c=(x_Rx_u-x_Rx_l)/d_sc_sf;
Nsf_r=(y_Rx_u-y_Rx_l)/d_sc_sf;
if Nsf_c==Nsf_r
    N_sf=Nsf_c;
end
delta = d_co_sF/d_sc_sf;

M = floor(8*delta+1);
h = zeros(M);
InitMap = randn(N_sf+M-1);


for i = 1:M
    for j = 1:M
        h(i,j) = exp(-sqrt(((M+1)/2-i).^2+((M+1)/2-j).^2)/d_co_sF);
    end
end

mu = 0;
CorrMapPad = conv2(InitMap,h,'same');
CorrMap = CorrMapPad((M+1)/2:(M+1)/2+N_sf-1,(M+1)/2:(M+1)/2+N_sf-1);
mu0 = mean(CorrMap(:));
sigma0 = sqrt(var(CorrMap(:)));
sfMap_LoS = CorrMap*(sigma_LoS/sigma0)+(mu-mu0);

end