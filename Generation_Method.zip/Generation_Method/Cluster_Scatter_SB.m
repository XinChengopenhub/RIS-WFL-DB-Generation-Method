function [C,S,p_c,p_c_s,belta_c_s]=Cluster_Scatter_SB(p_T,x,y,z_Rx,dim)
% A function generate clusters and scatters and for the SB-NLoS path

lambda_p=1.8;
d_0=1;
sigma_phi=5/180*pi;
sigma_theta=5/180*pi;
Sc_b=1;Sc_u=30;
x_Tx=p_T(1);
y_Tx=p_T(2);
z_Tx=p_T(3);
phi_max=pi/2; phi_min=-pi/2;
theta_max=pi/4;  theta_min=-pi/4;

C=max([1,poissrnd(lambda_p)]);  % Number of clusters
S=randi(Sc_u,Sc_b,C); % Number of scatters per cluster

phi_C=zeros(1,C);
theta_C=zeros(1,C);
for c=1:C
    phi_C(c)  = rand*(phi_max- phi_min)+phi_min;         % mean azimuth
    theta_C(c)= rand*(theta_max- theta_min)+theta_min;     % mean elevation
end
d_T_R=norm(p_T-[x;y;z_Rx],2);
d_T_C=d_0+rand(1,C)*(d_T_R-d_0); 

p_c=zeros(C,3);   
for c=1:C
    p_c(c,:)=[x_Tx + d_T_C(c)*cos(theta_C(c))*cos(phi_C(c)),...
        y_Tx + d_T_C(c)*cos(theta_C(c))*sin(phi_C(c)),...
        z_Tx + d_T_C(c)*sin(theta_C(c))] ;
end

% Correction on clusters
for c=1:C
    while p_c(c,3)>dim(3) || p_c(c,3)<0 ||  p_c(c,2)>dim(2) ||  p_c(c,2)<0  ||  p_c(c,1)>dim(1) ||  p_c(c,1)<0
        phi_C(c)  = rand*(phi_max- phi_min)+phi_min;         % mean azimuth
        theta_C(c)= rand*(theta_max- theta_min)+theta_min;     % mean elevation
        p_c(c,:)=[x_Tx + d_T_C(c)*cos(theta_C(c))*cos(phi_C(c)),...
            y_Tx + d_T_C(c)*cos(theta_C(c))*sin(phi_C(c)),...
            z_Tx + d_T_C(c)*sin(theta_C(c))] ;
    end
end


p_c_s=zeros(sum(S),3); 
d_T_C_S=[];
for c=1:C
    d_T_C_S=[d_T_C_S,repmat(d_T_C(c),1,S(c))];
end
phi_S=[ ];
theta_S=[ ];
for c=1:C
    phi_S   = [phi_S,log(rand(1,S(c))./rand(1,S(c)))*sqrt(sigma_phi^2/2) + phi_C(c)];
    theta_S = [theta_S,log(rand(1,S(c))./rand(1,S(c)))*sqrt(sigma_theta^2/2) + theta_C(c)];
end

for s=1:sum(S)
    p_c_s(s,:)=[x_Tx + d_T_C_S(s)*cos(theta_S(s))*cos(phi_S(s)),...
        y_Tx+d_T_C_S(s)*cos(theta_S(s))*sin(phi_S(s)),...
        z_Tx + d_T_C_S(s)*sin(theta_S(s))];
end

% Correction on scatters
for s=1:sum(S)
    while p_c_s(s,3)>dim(3) || p_c_s(s,3)<0 ||  p_c_s(s,2)>dim(2) ||  p_c_s(s,2)<0  ||  p_c_s(s,1)>dim(1) ||  p_c_s(s,1)<0
        S_sum=0;
        for c=1:C
            S_sum=S_sum+S(c);
            if s<=S_sum
                break
            end
        end
        p_c_s(s,:)=p_c(c,:);
    end
end

belta_c_s=zeros(sum(S),1);
for s=1:sum(S)
belta_c_s(s)=rand*exp(1i*rand*2*pi);
end

end